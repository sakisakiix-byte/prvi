<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign up</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <form action="index.php" method="post">
        <h1>Login</h1>
        <label for="username">Username:</label>
            <input type="text" id="username" name="username" required><br><br>
        <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br><br>
        <input type="submit" value="Login"><br>
        <a href="singupup.php">Don't have an account? Sing up now!</a>
    </form>
</body>
</html>
<?php
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    if ($username == "admin" && $password == "password123") {
        echo "Login successful! Welcome, " . htmlspecialchars($username) . ".";
    } else {
        echo "Invalid username or password.";
    }
?>